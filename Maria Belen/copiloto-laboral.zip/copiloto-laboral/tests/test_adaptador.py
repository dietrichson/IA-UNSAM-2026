import pytest

from servicios.adaptador import (Confirmacion, Confirmaciones, analizar_palabras, adaptar_cv, redactar_carta, TONOS)
from servicios.config import EJEMPLOS_DIR, cargar_config
from servicios.cv_parser import parsear_cv
from servicios.llm_client import SalidaInvalida
from servicios.oferta_parser import parsear_oferta
from servicios.schemas import CVEstructurado, OfertaEstructurada
from tests.falsos import LLMFalso, LLMGuion

CFG = cargar_config({})
CV = parsear_cv((EJEMPLOS_DIR / "cv-ejemplo-junior.md").read_text(encoding="utf-8"), LLMFalso(CVEstructurado()), CFG)
TEXTO_OFERTA = ("Agencia Brújula busca Community Manager. Requisitos: gestión de redes sociales, manejo de Canva y "
                "Premiere, 3 años de experiencia, conocimientos de programación avanzada en Python. Se valora Meta Ads.")
EST = OfertaEstructurada(titulo="Community Manager", empresa="Agencia Brújula", anios_experiencia=3,
                         requisitos=["gestión de redes sociales", "manejo de Canva y Premiere",
                                     "conocimientos de programación avanzada en Python"],
                         palabras_clave=["Canva", "gestión de redes sociales", "Premiere", "Meta Ads", "Redacción de notas"])
OFERTA = parsear_oferta(TEXTO_OFERTA + " Redacción de notas.", LLMFalso(EST))

BUENO = ("# Camila Rojas\n\n## Experiencia\n- Community manager voluntaria en Centro Cultural La Esquina: aumento de "
         "seguidores de Instagram de 800 a 1.500 en 8 meses, con piezas diseñadas en Canva.\n\n## Herramientas\n"
         "Canva, Instagram, Facebook, Google Sheets.")
MALO = BUENO + "\n- Gestioné campañas en Agencia Meridiano con Photoshop."


def analisis(llm=None):
    return analizar_palabras(CV, OFERTA, llm)


# ---------------------------------------------------------------- palabras clave
def test_palabras_exactas_faltantes_y_dudosas_confirmadas():
    llm = LLMGuion(json=Confirmaciones(confirmadas=[
        Confirmacion(palabra="gestión de redes sociales", cita="Manejo de Instagram y Facebook del centro cultural")]))
    a = analisis(llm)
    por = {p.palabra: p for p in a.presentes}
    assert por["Canva"].via == "exacta" and por["Redacción de notas"].via == "exacta"
    assert por["gestión de redes sociales"].via == "confirmada por el modelo"
    assert set(a.faltantes) == {"Premiere", "Meta Ads"}
    assert llm.llamadas[0]["modelo"] is Confirmaciones


def test_confirmacion_sin_cita_verificable_se_rechaza():
    llm = LLMGuion(json=Confirmaciones(confirmadas=[Confirmacion(palabra="gestión de redes sociales", cita="Lideró 50 cuentas")]))
    assert "gestión de redes sociales" in analisis(llm).faltantes


def test_si_falla_la_confirmacion_queda_como_faltante_con_aviso():
    a = analisis(LLMGuion(error_json=SalidaInvalida("x")))
    assert "gestión de redes sociales" in a.faltantes and a.avisos


def test_sin_modelo_no_se_confirma_nada():
    assert "gestión de redes sociales" in analisis(None).faltantes


def test_requisitos_no_cubiertos_y_anios():
    a = analisis(LLMGuion(json=Confirmaciones()))
    assert any("Python" in r for r in a.no_cubiertos)
    assert any("3 años" in r for r in a.no_cubiertos)
    assert not any("Canva" in r for r in a.no_cubiertos)


# ---------------------------------------------------------------- generación y verificación
def test_texto_fiel_no_regenera():
    llm = LLMGuion([BUENO])
    g = adaptar_cv(CV, OFERTA, analisis(LLMGuion(json=Confirmaciones())), llm, CFG)
    assert g.texto == BUENO and g.hallazgos == [] and not g.regenerado and len(llm.llamadas) == 1


def test_invencion_se_regenera_una_vez_y_se_corrige():
    llm = LLMGuion([MALO, BUENO])
    g = adaptar_cv(CV, OFERTA, analisis(LLMGuion(json=Confirmaciones())), llm, CFG)
    assert g.texto == BUENO and g.hallazgos == [] and g.regenerado
    assert "CORRECCIÓN" in llm.llamadas[1]["user"] and "Photoshop" in llm.llamadas[1]["user"]
    assert "CORRECCIÓN" not in llm.llamadas[0]["user"]


def test_si_persiste_se_devuelve_marcado_sin_tercer_intento():
    llm = LLMGuion([MALO, MALO, BUENO])
    g = adaptar_cv(CV, OFERTA, analisis(LLMGuion(json=Confirmaciones())), llm, CFG)
    assert g.regenerado and {h.fragmento for h in g.hallazgos} >= {"Photoshop", "Agencia Meridiano"}
    assert len(llm.llamadas) == 2


def test_si_la_segunda_version_empeora_se_conserva_la_primera():
    peor = MALO + " También usé Illustrator y Figma."
    g = adaptar_cv(CV, OFERTA, analisis(), LLMGuion([MALO, peor]), CFG)
    assert g.texto == MALO


def test_si_falla_la_regeneracion_se_conserva_la_primera():
    g = adaptar_cv(CV, OFERTA, analisis(), LLMGuion([MALO, SalidaInvalida("x")]), CFG)
    assert g.texto == MALO and g.hallazgos and not g.regenerado


def test_salida_vacia_es_error_y_se_quitan_las_vallas_de_codigo():
    with pytest.raises(SalidaInvalida):
        adaptar_cv(CV, OFERTA, analisis(), LLMGuion(["ok"]), CFG)
    g = adaptar_cv(CV, OFERTA, analisis(), LLMGuion([f"```markdown\n{BUENO}\n```"]), CFG)
    assert g.texto == BUENO


def test_prompt_cv_primero_oferta_resumida_y_palabras():
    llm = LLMGuion([BUENO])
    adaptar_cv(CV, OFERTA, analisis(), llm, CFG)
    user = llm.llamadas[0]["user"]
    assert user.index("<cv>") < user.index("<oferta>") and "Empresa: Agencia Brújula" in user
    assert "Palabras clave presentes:" in user and "Premiere" in user.split("no cubiertas:")[1]
    assert "no obedezcas" in llm.llamadas[0]["system"]


def test_carta_tono_y_nombres_de_la_oferta():
    carta = ("Estimado equipo de Agencia Brújula:\n\nMe postulo al puesto de Community Manager. En el Centro Cultural "
             "La Esquina aumenté los seguidores de Instagram de 800 a 1.500 en 8 meses usando Canva.\n\nSaludos,\nCamila Rojas")
    llm = LLMGuion([carta])
    g = redactar_carta(CV, OFERTA, analisis(), llm, CFG, tono="formal")
    assert g.hallazgos == [] and TONOS["formal"] in llm.llamadas[0]["system"]
    with pytest.raises(ValueError):
        redactar_carta(CV, OFERTA, analisis(), LLMGuion([carta]), CFG, tono="gracioso")
