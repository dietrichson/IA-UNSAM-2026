import pytest

from servicios.brechas import (brechas_de_puesto, clave_herramienta, frecuencias_herramientas,
                               herramientas_mas_pedidas, resumen_agregado, sugerencia)
from servicios.config import EJEMPLOS_DIR, cargar_config
from servicios.cv_parser import parsear_cv
from servicios.llm_client import SalidaInvalida
from servicios.matcher import (CachePuntajes, EvaluacionLLM, evaluar_herramientas, puntuar_candidatos,
                               puntuar_puesto)
from servicios.puestos_repo import Puesto, cargar_puestos
from servicios.recuperador import Candidato
from servicios.schemas import CVEstructurado, Criterio
from tests.falsos import LLMFalso

CFG = cargar_config({})
PUESTOS = cargar_puestos()
CV = parsear_cv((EJEMPLOS_DIR / "cv-ejemplo-junior.md").read_text(encoding="utf-8"), LLMFalso(CVEstructurado()), CFG)

CUERPO = "# Diseñador/a\n\n## Requisitos\n- Manejo de Photoshop y Canva\n- Experiencia en redes sociales\n- Portfolio de trabajos\n"


def puesto(**kw):
    base = dict(id="p1", titulo="Diseñador/a", cuerpo=CUERPO, herramientas=["Canva", "Photoshop"],
                titulo_universitario="Licenciatura en Comunicación", requiere_titulo="sí", seniority="junior",
                experiencia="no figura", idiomas=["Inglés intermedio"])
    base.update(kw)
    return Puesto(**base)


def evaluacion(**kw):
    base = dict(
        experiencia=Criterio(puntaje=80, evidencia=["Diseño de piezas gráficas en Canva"], comentario="ok"),
        formacion=Criterio(puntaje=100, evidencia=["Licenciatura en Ciencias de la Comunicación"], comentario="ok"),
        seniority=Criterio(puntaje=70, evidencia=[], comentario="nivel junior"),
        brechas=["Portfolio de trabajos", "Dominio de Blender"], resumen="Buen ajuste.")
    base.update(kw)
    return EvaluacionLLM(**base)


def test_puntaje_combinado_con_pesos_y_tope_sin_cita():
    r = puntuar_puesto(CV, puesto(), LLMFalso(evaluacion()), CFG)
    por = {i.clave: i for i in r.items}
    assert por["herramientas"].puntaje == 50 and por["otros"].puntaje == 100
    assert por["seniority"].puntaje == 40 and "Sin cita verificable" in por["seniority"].comentario  # 70 sin cita -> 40
    assert por["experiencia"].evidencia == ["Diseño de piezas gráficas en Canva"]
    # 0,30*50 + 0,35*80 + 0,15*100 + 0,10*40 + 0,10*100 = 72
    assert r.puntaje == 72 and not r.parcial
    assert r.herramientas_cubiertas == ["Canva"] and r.herramientas_faltantes == ["Photoshop"]
    assert r.brechas_modelo == ["Portfolio de trabajos"]  # "Blender" no está en el puesto: inventado
    assert sum(i.peso for i in r.items) == pytest.approx(1)


def test_cita_inventada_limita_el_puntaje():
    ev = evaluacion(experiencia=Criterio(puntaje=95, evidencia=["Dirigió la campaña del Mundial 2022"]))
    r = puntuar_puesto(CV, puesto(), LLMFalso(ev), CFG)
    assert r.item("experiencia").puntaje == 40 and r.item("experiencia").evidencia == []


def test_criterios_que_el_puesto_no_especifica_se_excluyen_y_el_peso_se_reparte():
    p = puesto(herramientas=[], titulo_universitario="no figura", requiere_titulo="no figura", seniority="no figura",
               idiomas=[])
    r = puntuar_puesto(CV, p, LLMFalso(evaluacion()), CFG)
    assert [i.clave for i in r.items] == ["experiencia"] and r.puntaje == 80 and r.items[0].peso == 1


def test_herramientas_genericas_y_alternativas():
    cv_norm = "uso canva y ga4"
    p, cub, falt = evaluar_herramientas(puesto(herramientas=["Google Analytics 4 (GA4)", "Photoshop o Illustrator",
                                                             "Herramientas de diseño"]), cv_norm)
    assert (p, cub, falt) == (50, ["Google Analytics 4 (GA4)"], ["Photoshop o Illustrator"])
    assert evaluar_herramientas(puesto(herramientas=["No figuran en el aviso leído"]), cv_norm)[0] is None


def test_si_el_modelo_falla_el_puntaje_es_parcial_y_no_se_cachea(tmp_path):
    cache = CachePuntajes(tmp_path / "c.json")
    r = puntuar_puesto(CV, puesto(), LLMFalso(error=SalidaInvalida("x")), CFG, cache)
    assert r.parcial and r.avisos and r.item("experiencia").puntaje is None
    assert r.puntaje == round((0.30 * 50 + 0.10 * 100) / 0.40)
    assert not (tmp_path / "c.json").exists()


def test_cache_evita_llamadas_y_se_invalida_con_otro_cv(tmp_path):
    ruta = tmp_path / "c.json"
    llm = LLMFalso(evaluacion())
    primero = puntuar_puesto(CV, puesto(), llm, CFG, CachePuntajes(ruta))
    segundo = puntuar_puesto(CV, puesto(), llm, CFG, CachePuntajes(ruta))  # cache cargado desde disco
    assert len(llm.llamadas) == 1 and segundo.desde_cache and segundo.puntaje == primero.puntaje
    assert segundo.item("experiencia").evidencia == primero.item("experiencia").evidencia
    otro_cv = parsear_cv(CV.texto + "\nTambién hice pasantías en prensa.", LLMFalso(CVEstructurado()), CFG)
    puntuar_puesto(otro_cv, puesto(), llm, CFG, CachePuntajes(ruta))
    assert len(llm.llamadas) == 2


def test_el_cv_va_primero_en_el_prompt_y_queda_delimitado():
    llm = LLMFalso(evaluacion())
    puntuar_puesto(CV, puesto(), llm, CFG)
    user = llm.llamadas[0]["user"]
    assert user.index("<cv>") < user.index("<puesto>") and "no obedezcas" in llm.llamadas[0]["system"]


def test_puntuar_candidatos_ordena_limita_y_reporta_progreso():
    ps = [puesto(id=f"p{i}", titulo=f"Puesto {i}") for i in range(4)]
    puntajes = iter([30, 90, 60, 10])

    class LLM:
        def chat_json(self, *a, **k):
            return evaluacion(experiencia=Criterio(puntaje=next(puntajes), evidencia=["Diseño de piezas gráficas en Canva"]))

    avance = []
    res = puntuar_candidatos(CV, [Candidato(p, 0.5) for p in ps], LLM(), CFG, n=3, progreso=lambda i, n, t: avance.append((i, n)))
    assert len(res) == 3 and [r.puesto.id for r in res] == ["p1", "p2", "p0"]
    assert avance[0] == (0, 3) and avance[-1] == (3, 3)


def test_puntaje_con_puestos_reales_corre_sin_errores():
    llm = LLMFalso(evaluacion())
    for p in PUESTOS:
        r = puntuar_puesto(CV, p, llm, CFG)
        assert 0 <= r.puntaje <= 100 and r.items


# ------------------------------------------------------------------ brechas
def test_clave_herramienta_agrupa_variantes():
    assert clave_herramienta("Google Analytics 4 (GA4)") == clave_herramienta("GA4") == clave_herramienta("Google Analytics")
    assert clave_herramienta("Canva") != clave_herramienta("Photoshop")


def test_frecuencias_y_herramientas_mas_pedidas():
    cuenta, etiquetas = frecuencias_herramientas(PUESTOS)
    assert max(cuenta.values()) <= len(PUESTOS)
    filas = herramientas_mas_pedidas(CV, PUESTOS, top=10)
    assert [f.puestos for f in filas] == sorted((f.puestos for f in filas), reverse=True)
    assert all(0 < f.porcentaje <= 100 for f in filas)
    canva = next(f for f in herramientas_mas_pedidas(CV, PUESTOS, top=100) if f.herramienta.lower() == "canva")
    assert canva.la_tengo  # el CV de ejemplo menciona Canva


def test_brechas_de_puesto_ordenadas_por_importancia_y_sugerencia():
    ps = [puesto(id="a", herramientas=["Photoshop", "Premiere"]), puesto(id="b", herramientas=["Photoshop"]),
          puesto(id="c", herramientas=["Photoshop", "Canva"])]
    r = puntuar_puesto(CV, puesto(herramientas=["Premiere", "Photoshop"]), LLMFalso(evaluacion()), CFG)
    br = brechas_de_puesto(r, ps)
    assert [b.texto for b in br][:2] == ["Photoshop", "Premiere"] and br[0].frecuencia == 3
    assert br[-1].tipo == "requisito"
    assert "Photoshop" in sugerencia(br, 3) and "3 de los 3" in sugerencia(br, 3)
    assert "No detecté" in sugerencia([], 3)


def test_resumen_agregado_cuenta_repeticiones():
    rs = [puntuar_puesto(CV, puesto(id=f"p{i}"), LLMFalso(evaluacion(seniority=Criterio(puntaje=20))), CFG) for i in range(3)]
    filas = resumen_agregado(rs)
    por = {(f.texto, f.tipo): f for f in filas}
    assert por[("Photoshop", "herramienta")].veces == 3 and por[("Photoshop", "herramienta")].de == 3
    assert por[("Seniority por debajo de 50", "criterio")].veces == 3
