"""Vocabulario de herramientas, sinónimos e idiomas.

Sirve para tres cosas: detectar qué herramientas menciona un texto, decidir si un CV
cubre una herramienta que pide un puesto (incluyendo equivalentes básicos) y alimentar
el verificador anti-invención.
"""
from __future__ import annotations

import re

from servicios.texto import contiene_termino, normalizar

HERRAMIENTAS_COMUNES = [
    "Canva", "Photoshop", "Illustrator", "InDesign", "Premiere", "Premiere Pro", "After Effects", "CapCut",
    "Figma", "Final Cut Pro", "Excel", "Word", "PowerPoint", "Google Sheets", "Google Drive", "Google Docs",
    "Google Analytics", "GA4", "Looker Studio", "Search Console", "Google Ads", "Meta Ads", "Facebook Ads",
    "Meta Business Suite", "LinkedIn Ads", "TikTok Ads", "Mailchimp", "HubSpot", "Salesforce", "WordPress",
    "Wix", "Shopify", "Tienda Nube", "Notion", "Trello", "Asana", "Slack", "Microsoft Teams", "Teams", "Zoom",
    "SharePoint", "Microsoft 365", "Hootsuite", "Buffer", "Metricool", "Later", "ChatGPT", "Gemini", "Claude",
    "Perplexity", "Copilot", "SEMrush", "Ahrefs", "Zapier", "n8n", "Make", "Instagram", "Facebook", "TikTok",
    "YouTube", "LinkedIn", "Twitter", "Pinterest", "WhatsApp", "Reddit", "Intranet", "Newsletter", "SEO",
    "Sitecore", "Drupal", "AEM", "Frame.io", "Viva Engage", "Bing Places", "Google Business Profile",
    "Yelp", "Trustpilot", "GoHighLevel", "CRM", "Apps Script", "Metricool", "Adobe Express",
]

# Grupos de equivalencia básicos (todo en forma normalizada: minúsculas, sin tildes).
SINONIMOS: list[set[str]] = [
    {"meta ads", "facebook ads", "instagram ads", "anuncios en meta", "anuncios de facebook"},
    {"ga4", "google analytics 4", "google analytics"},
    {"looker studio", "data studio", "google data studio"},
    {"premiere", "premiere pro", "adobe premiere"},
    {"photoshop", "adobe photoshop"},
    {"illustrator", "adobe illustrator"},
    {"after effects", "adobe after effects"},
    {"excel", "microsoft excel", "planilla de calculo", "planillas de calculo", "hojas de calculo", "google sheets"},
    {"chatgpt", "chat gpt", "gpt"},
    {"microsoft 365", "office 365", "m365", "paquete office", "microsoft office"},
    {"search console", "google search console", "gsc"},
    {"google ads", "adwords", "google adwords"},
    {"tienda nube", "tiendanube"},
    {"capcut", "cap cut"},
    {"seo", "posicionamiento organico", "posicionamiento en buscadores"},
    {"crm", "salesforce", "hubspot", "zoho", "pipedrive"},
    {"newsletter", "newsletters", "boletin", "boletines"},
    {"teams", "microsoft teams"},
]

IDIOMAS = {
    "inglés": ("ingles", "english"),
    "portugués": ("portugues", "portuguese"),
    "francés": ("frances", "french"),
    "italiano": ("italiano", "italian"),
    "alemán": ("aleman", "german"),
}

_PALABRAS_SUELTAS_RUIDOSAS = {"make", "later", "teams", "word", "claude", "gemini"}


def grupo_de(termino_norm: str) -> set[str]:
    for g in SINONIMOS:
        if termino_norm in g:
            return set(g)
    return {termino_norm}


def alternativas(item: str) -> list[str]:
    """Descompone un ítem de la lista de herramientas de un puesto en alternativas normalizadas.

    "Google Analytics 4 (GA4)" -> ["google analytics 4", "ga4"];
    "ChatGPT, Claude, Gemini o Perplexity" -> cuatro alternativas (alcanza con una)."""
    fuera = re.sub(r"\(.*?\)", " ", item)
    dentro = re.findall(r"\((.*?)\)", item)
    salida: list[str] = []
    for bloque in [fuera, *dentro]:
        for parte in re.split(r",|/|;| o | y | u ", bloque):
            p = normalizar(parte)
            if len(p) >= 2 and p not in salida and p not in {"sin especificar", "preferentemente"}:
                salida.append(p)
    return salida


def es_generica(item: str) -> bool:
    n = normalizar(item)
    return n.startswith("herramientas de") or n in {"redes sociales", "no figuran en el aviso leido"}


def herramienta_cubierta(item: str, texto_norm: str) -> bool:
    """¿El texto (ya normalizado) menciona la herramienta o algún equivalente básico?"""
    for alt in alternativas(item):
        for t in grupo_de(alt):
            if contiene_termino(texto_norm, t):
                return True
    return False


def herramientas_en_texto(texto: str, extra: list[str] | None = None) -> list[str]:
    """Herramientas del vocabulario que el texto menciona (se devuelve el nombre canónico)."""
    base = normalizar(texto)
    vistos: set[str] = set()
    salida: list[str] = []
    for nombre in [*HERRAMIENTAS_COMUNES, *(extra or [])]:
        n = normalizar(nombre)
        if n in vistos or len(n) < 2:
            continue
        vistos.add(n)
        if contiene_termino(base, n):
            salida.append(nombre)
    return salida


def vocabulario_desde_puestos(puestos) -> list[str]:
    """Nombres de herramientas de la base de puestos (una por alternativa corta)."""
    nombres: list[str] = []
    for p in puestos:
        for item in p.herramientas:
            if es_generica(item):
                continue
            for alt in re.split(r",|/|;| o ", re.sub(r"\(.*?\)", " ", item)):
                alt = alt.strip()
                if 2 < len(alt) <= 30 and normalizar(alt) not in {normalizar(n) for n in nombres}:
                    nombres.append(alt)
    return nombres


def idiomas_en_texto(texto: str) -> list[str]:
    base = normalizar(texto)
    return [nombre.capitalize() for nombre, claves in IDIOMAS.items() if any(contiene_termino(base, c) for c in claves)]


def es_ruidosa(nombre: str) -> bool:
    """Palabras que pueden ser herramienta o palabra común; el verificador las trata con cuidado."""
    return normalizar(nombre) in _PALABRAS_SUELTAS_RUIDOSAS
