"""Carga de la base de puestos (archivos `.md` con encabezado en `data/puestos/`)."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from servicios.config import PUESTOS_DIR
from servicios.texto import truncar

CLAVES = [
    "id", "titulo", "empresa", "area", "seniority", "experiencia", "titulo_universitario", "requiere_titulo",
    "modalidad", "modalidad_tipo", "ubicacion", "herramientas", "idiomas", "lectura", "fuente", "publicado",
    "relevado", "notas",
]
NO_FIGURA = "no figura"


@dataclass
class Puesto:
    id: str
    titulo: str
    cuerpo: str
    empresa: str = NO_FIGURA
    area: str = NO_FIGURA
    seniority: str = NO_FIGURA
    experiencia: str = NO_FIGURA
    titulo_universitario: str = NO_FIGURA
    requiere_titulo: str = NO_FIGURA
    modalidad: str = NO_FIGURA
    modalidad_tipo: str = NO_FIGURA
    ubicacion: str = NO_FIGURA
    herramientas: list[str] = field(default_factory=list)
    idiomas: list[str] = field(default_factory=list)
    lectura: str = "aviso completo"
    fuente: list[str] = field(default_factory=list)
    publicado: str = NO_FIGURA
    relevado: str = NO_FIGURA
    notas: list[str] = field(default_factory=list)

    @property
    def texto_embedding(self) -> str:
        """Lo que se convierte en vector: todo el cuerpo (las notas viven en el encabezado)."""
        return self.cuerpo

    def para_prompt(self, maximo: int = 3000) -> str:
        """Texto compacto del puesto para el modelo (los datos del encabezado que importan + el cuerpo)."""
        lineas = [f"Puesto: {self.titulo}"]
        for etiqueta, valor in (("Seniority", self.seniority), ("Experiencia", self.experiencia),
                                ("Formación", self.titulo_universitario), ("Modalidad", self.modalidad)):
            if valor and valor.lower() != NO_FIGURA:
                lineas.append(f"{etiqueta}: {valor}")
        if self.idiomas:
            lineas.append("Idiomas: " + "; ".join(self.idiomas))
        cuerpo = re.sub(r"^# .*\n+", "", self.cuerpo.strip(), count=1)
        texto, _ = truncar("\n".join(lineas) + "\n\n" + cuerpo, maximo)
        return texto


def parsear_puesto(texto: str, origen: str = "") -> Puesto:
    m = re.match(r"---\n(.*?)\n---\n\n?(.*)", texto, re.S)
    if not m:
        raise ValueError(f"{origen}: el archivo no empieza con un encabezado entre '---'")
    datos: dict = {}
    for linea in m.group(1).splitlines():
        if ": " not in linea:
            raise ValueError(f"{origen}: línea de encabezado inválida: {linea[:60]!r}")
        clave, valor = linea.split(": ", 1)
        try:
            datos[clave] = json.loads(valor)
        except json.JSONDecodeError as e:
            raise ValueError(f"{origen}: el valor de '{clave}' no es JSON válido ({e.msg})") from e
    faltan = [c for c in CLAVES if c not in datos]
    if faltan:
        raise ValueError(f"{origen}: faltan campos en el encabezado: {', '.join(faltan)}")
    return Puesto(cuerpo=m.group(2).strip() + "\n", **{c: datos[c] for c in CLAVES})


def cargar_puestos(carpeta: Path | str = PUESTOS_DIR) -> list[Puesto]:
    carpeta = Path(carpeta)
    puestos = []
    for ruta in sorted(carpeta.glob("*.md")):
        puestos.append(parsear_puesto(ruta.read_text(encoding="utf-8"), ruta.name))
    ids = [p.id for p in puestos]
    if len(set(ids)) != len(ids):
        raise ValueError("Hay ids de puestos repetidos en la base")
    return puestos


def puesto_desde_oferta(texto: str, oferta) -> Puesto:
    """Arma un `Puesto` temporal a partir de una oferta pegada y su extracción estructurada."""
    titulo = (oferta.titulo or "Puesto pegado").strip()
    cuerpo = [f"# {titulo}", ""]
    if oferta.requisitos:
        cuerpo += ["## Requisitos", *[f"- {r}" for r in oferta.requisitos], ""]
    if oferta.deseables:
        cuerpo += ["## Deseables", *[f"- {r}" for r in oferta.deseables], ""]
    texto_corto, _ = truncar(texto.strip(), 2500)
    cuerpo += ["## Texto de la oferta", texto_corto, ""]
    return Puesto(
        id="oferta-pegada", titulo=titulo, cuerpo="\n".join(cuerpo),
        empresa=oferta.empresa or NO_FIGURA, herramientas=list(oferta.herramientas),
        idiomas=list(oferta.idiomas), lectura="aviso completo", fuente=["Texto pegado por la persona"],
    )
