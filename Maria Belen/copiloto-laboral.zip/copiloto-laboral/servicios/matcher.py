"""Matcher: puntaje de ajuste entre un CV y cada puesto.

Reparto del puntaje (pesos del diseño): herramientas 30 %, experiencia 35 %, formación 15 %,
seniority 10 %, otros (idiomas) 10 %.

- Herramientas e idiomas se calculan con reglas (reproducibles y baratas).
- Experiencia, formación y seniority los juzga el modelo, un puesto por llamada, y cada
  puntaje alto debe venir con una cita del CV que se verifica; si no, queda limitado a 40.
- Los criterios que el puesto no especifica no se puntúan y su peso se reparte entre los demás.
- Los resultados se guardan en un caché local para no repetir llamadas lentas.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable

from pydantic import Field

from servicios.config import LOCAL_DIR, Config
from servicios.llm_client import SalidaInvalida
from servicios.prompts import cargar
from servicios.puestos_repo import Puesto
from servicios.schemas import Base, Criterio
from servicios.texto import delimitar, hash_texto, normalizar, respaldado, truncar
from servicios.vocabulario import es_generica, herramienta_cubierta, idiomas_en_texto

PESOS = {"herramientas": 0.30, "experiencia": 0.35, "formacion": 0.15, "seniority": 0.10, "otros": 0.10}
ETIQUETAS = {"herramientas": "Herramientas", "experiencia": "Experiencia", "formacion": "Formación",
             "seniority": "Seniority", "otros": "Idiomas"}
TOPE_SIN_CITA = 40
MAX_CV_PUNTAJE = 4000
MAX_PUESTO_PUNTAJE = 2800


class EvaluacionLLM(Base):
    experiencia: Criterio = Field(default_factory=Criterio)
    formacion: Criterio = Field(default_factory=Criterio)
    seniority: Criterio = Field(default_factory=Criterio)
    brechas: list[str] = Field(default_factory=list)
    resumen: str = ""


@dataclass
class ItemPuntaje:
    clave: str
    etiqueta: str
    puntaje: int | None  # None: no se pudo evaluar
    peso: float = 0.0  # peso efectivo (los de un puesto suman 1)
    evidencia: list[str] = field(default_factory=list)
    comentario: str = ""


@dataclass
class ResultadoPuesto:
    puesto: Puesto
    puntaje: int
    items: list[ItemPuntaje]
    herramientas_cubiertas: list[str] = field(default_factory=list)
    herramientas_faltantes: list[str] = field(default_factory=list)
    brechas_modelo: list[str] = field(default_factory=list)
    resumen: str = ""
    avisos: list[str] = field(default_factory=list)
    parcial: bool = False  # el modelo no pudo evaluar experiencia/formación/seniority
    desde_cache: bool = False

    def item(self, clave: str) -> ItemPuntaje | None:
        return next((i for i in self.items if i.clave == clave), None)

    def a_dict(self) -> dict:
        d = asdict(self)
        d.pop("puesto")
        d.pop("desde_cache")
        return d

    @classmethod
    def desde_dict(cls, d: dict, puesto: Puesto) -> "ResultadoPuesto":
        return cls(puesto=puesto, items=[ItemPuntaje(**i) for i in d["items"]], desde_cache=True,
                   **{k: v for k, v in d.items() if k != "items"})


def _dato(valor: str) -> bool:
    return bool(valor) and not normalizar(valor).startswith("no figura")


# --------------------------------------------------------------------- criterios por reglas
def evaluar_herramientas(puesto: Puesto, cv_norm: str) -> tuple[int | None, list[str], list[str]]:
    pedidas = [h for h in puesto.herramientas if not es_generica(h)]
    if not pedidas:
        return None, [], []
    cubiertas = [h for h in pedidas if herramienta_cubierta(h, cv_norm)]
    faltantes = [h for h in pedidas if h not in cubiertas]
    return round(100 * len(cubiertas) / len(pedidas)), cubiertas, faltantes


def evaluar_idiomas(puesto: Puesto, cv) -> tuple[int | None, str]:
    """Idiomas pedidos que el CV menciona (el nivel no se compara)."""
    pedidos = list(dict.fromkeys(i for texto in puesto.idiomas for i in idiomas_en_texto(texto)))
    if not pedidos:
        return None, ""
    tiene = set(idiomas_en_texto(" ".join(cv.idiomas))) | set(idiomas_en_texto(cv.texto))
    ok = [i for i in pedidos if i in tiene]
    falta = [i for i in pedidos if i not in tiene]
    texto = f"Pide {', '.join(pedidos)}; el CV menciona {', '.join(ok) if ok else 'ninguno'} (no se compara el nivel)."
    if falta:
        texto += f" Falta: {', '.join(falta)}."
    return round(100 * len(ok) / len(pedidos)), texto


def _aplica(puesto: Puesto) -> dict[str, bool]:
    return {"formacion": _dato(puesto.titulo_universitario) or _dato(puesto.requiere_titulo),
            "seniority": _dato(puesto.seniority) or _dato(puesto.experiencia)}


# --------------------------------------------------------------------- caché
class CachePuntajes:
    def __init__(self, ruta: Path | str | None = None, maximo: int = 500):
        self.ruta = Path(ruta) if ruta else LOCAL_DIR / "cache_puntajes.json"
        self.maximo = maximo
        try:
            self._datos: dict = json.loads(self.ruta.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self._datos = {}

    def get(self, clave: str) -> dict | None:
        return self._datos.get(clave)

    def set(self, clave: str, valor: dict) -> None:
        self._datos.pop(clave, None)
        self._datos[clave] = valor
        while len(self._datos) > self.maximo:
            self._datos.pop(next(iter(self._datos)))
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.ruta.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._datos, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.ruta)

    def vaciar(self) -> None:
        self._datos = {}
        self.ruta.unlink(missing_ok=True)


# --------------------------------------------------------------------- puntaje de un puesto
def _limitar(c: Criterio, cv_texto: str) -> ItemPuntaje | None:
    evidencia = [q for q in c.evidencia if respaldado(q, cv_texto, 0.7)]
    puntaje, comentario = c.puntaje, c.comentario
    if puntaje > TOPE_SIN_CITA and not evidencia:
        puntaje = TOPE_SIN_CITA
        comentario = (comentario + " " if comentario else "") + "(Sin cita verificable en el CV: puntaje limitado.)"
    return puntaje, evidencia, comentario  # type: ignore[return-value]


def puntuar_puesto(cv, puesto: Puesto, llm, cfg: Config, cache: CachePuntajes | None = None) -> ResultadoPuesto:
    cv_texto, _ = truncar(cv.texto, MAX_CV_PUNTAJE)
    sistema = cargar("puntuar_puesto")
    texto_puesto = puesto.para_prompt(MAX_PUESTO_PUNTAJE)
    clave = hash_texto(f"{cv_texto}|{puesto.id}|{texto_puesto}|{cfg.modelo_principal}|{sistema}")
    if cache and (hit := cache.get(clave)):
        return ResultadoPuesto.desde_dict(hit, puesto)

    avisos: list[str] = []
    items: dict[str, ItemPuntaje] = {}
    cv_norm = normalizar(cv.texto)

    p_herr, cubiertas, faltantes = evaluar_herramientas(puesto, cv_norm)
    if p_herr is not None:
        items["herramientas"] = ItemPuntaje("herramientas", ETIQUETAS["herramientas"], p_herr,
                                            comentario=f"Cubre {len(cubiertas)} de {len(cubiertas) + len(faltantes)}.")
    p_idi, texto_idi = evaluar_idiomas(puesto, cv)
    if p_idi is not None:
        items["otros"] = ItemPuntaje("otros", ETIQUETAS["otros"], p_idi, comentario=texto_idi)

    aplica = _aplica(puesto)
    parcial, brechas, resumen = False, [], ""
    try:
        ev = llm.chat_json(sistema, delimitar("cv", cv_texto) + "\n\n" + delimitar("puesto", texto_puesto)
                           + "\n\nEvaluá el ajuste del CV con el puesto.", EvaluacionLLM, rol="principal",
                           max_tokens=700)
        for clave_c in ("experiencia", "formacion", "seniority"):
            if clave_c != "experiencia" and not aplica[clave_c]:
                continue  # el puesto no lo especifica: no se puntúa
            puntaje, evidencia, comentario = _limitar(getattr(ev, clave_c), cv.texto)
            items[clave_c] = ItemPuntaje(clave_c, ETIQUETAS[clave_c], puntaje, evidencia=evidencia, comentario=comentario)
        brechas = [b for b in ev.brechas if respaldado(b, puesto.cuerpo + " " + texto_puesto, 0.6)][:5]
        resumen = ev.resumen
    except SalidaInvalida:
        parcial = True
        avisos.append("El modelo no pudo evaluar este puesto (respuesta inválida). "
                      "El puntaje usa solo herramientas e idiomas y no es comparable.")
        items["experiencia"] = ItemPuntaje("experiencia", ETIQUETAS["experiencia"], None, comentario="No evaluado.")

    activos = {k: i for k, i in items.items() if i.puntaje is not None}
    suma = sum(PESOS[k] for k in activos) or 1.0
    for k, i in activos.items():
        i.peso = PESOS[k] / suma
    total = round(sum(i.peso * i.puntaje for i in activos.values())) if activos else 0
    orden = list(PESOS)
    res = ResultadoPuesto(puesto=puesto, puntaje=total, items=sorted(items.values(), key=lambda i: orden.index(i.clave)),
                          herramientas_cubiertas=cubiertas, herramientas_faltantes=faltantes,
                          brechas_modelo=brechas, resumen=resumen, avisos=avisos, parcial=parcial)
    if cache and not parcial:
        cache.set(clave, res.a_dict())
    return res


def puntuar_candidatos(cv, candidatos, llm, cfg: Config, n: int | None = None, cache: CachePuntajes | None = None,
                       progreso: Callable[[int, int, str], None] | None = None) -> list[ResultadoPuesto]:
    """Puntúa los primeros `n` candidatos (Candidato o Puesto) y los ordena de mayor a menor."""
    puestos = [getattr(c, "puesto", c) for c in candidatos][: (n or cfg.puntuar_n)]
    resultados = []
    for i, p in enumerate(puestos):
        if progreso:
            progreso(i, len(puestos), p.titulo)
        resultados.append(puntuar_puesto(cv, p, llm, cfg, cache))
    if progreso:
        progreso(len(puestos), len(puestos), "")
    return sorted(resultados, key=lambda r: (r.parcial, -r.puntaje))
