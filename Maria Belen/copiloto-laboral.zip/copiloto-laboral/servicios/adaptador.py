"""Adaptador: palabras clave presentes/faltantes, CV adaptado y carta (A3 a A8).

Flujo: comparar palabras clave (reglas + confirmación del modelo para los casos dudosos) ->
generar CV o carta usando solo el CV original -> verificar -> si hay datos no respaldados,
regenerar UNA vez -> lo que persista se devuelve marcado para que la persona lo revise.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from pydantic import Field

from servicios.config import Config
from servicios.llm_client import LLMError, SalidaInvalida
from servicios.oferta_parser import OfertaProcesada
from servicios.prompts import cargar
from servicios.schemas import Base
from servicios.texto import contiene_termino, delimitar, normalizar, respaldado, truncar
from servicios.vocabulario import grupo_de
from servicios.verificador import Hallazgo, verificar

TONOS = {
    "formal": "Tono formal y profesional: tratamiento de usted, frases claras, sin coloquialismos.",
    "cercano": "Tono cercano y cordial: natural y amable, en primera persona, sin perder profesionalismo.",
    "creativo": "Tono creativo: abrí con una frase original que muestre personalidad, pero sin exagerar ni inventar.",
}
MAX_DUDOSAS = 8
MAX_CV_ADAPTAR = 4000
MAX_OFERTA_RESUMEN = 1500


class Confirmacion(Base):
    palabra: str = ""
    cita: str = ""


class Confirmaciones(Base):
    confirmadas: list[Confirmacion] = Field(default_factory=list)


@dataclass
class PalabraPresente:
    palabra: str
    via: str  # "exacta" | "sinónimo" | "confirmada por el modelo"
    cita: str = ""


@dataclass
class AnalisisPalabras:
    presentes: list[PalabraPresente] = field(default_factory=list)
    faltantes: list[str] = field(default_factory=list)
    no_cubiertos: list[str] = field(default_factory=list)  # requisitos del aviso que el CV no permite cubrir (A7)
    avisos: list[str] = field(default_factory=list)


@dataclass
class Generado:
    texto: str
    hallazgos: list[Hallazgo] = field(default_factory=list)  # lo que sigue sin respaldo después de regenerar
    regenerado: bool = False


def _raices(texto: str) -> set[str]:
    return {t[:5] for t in normalizar(texto).split() if len(t) >= 5}


def _esta(palabra: str, cv_norm: str) -> str | None:
    if contiene_termino(cv_norm, palabra):
        return "exacta"
    if any(contiene_termino(cv_norm, s) for s in grupo_de(normalizar(palabra)) if s != normalizar(palabra)):
        return "sinónimo"
    return None


def analizar_palabras(cv, oferta: OfertaProcesada, llm=None) -> AnalisisPalabras:
    cv_norm, raices_cv = cv.texto_norm, _raices(cv.texto)
    res = AnalisisPalabras()
    dudosas: list[str] = []
    for k in oferta.palabras_clave:
        via = _esta(k, cv_norm)
        if via:
            res.presentes.append(PalabraPresente(k, via))
        elif _raices(k) & raices_cv:
            dudosas.append(k)
        else:
            res.faltantes.append(k)

    if dudosas and llm is not None:
        confirmadas: dict[str, str] = {}
        try:
            r = llm.chat_json(cargar("confirmar_palabras"),
                              delimitar("cv", truncar(cv.texto, MAX_CV_ADAPTAR)[0]) + "\n\n"
                              + delimitar("palabras", "\n".join(f"- {d}" for d in dudosas[:MAX_DUDOSAS])),
                              Confirmaciones, rol="liviano", max_tokens=500)
            for c in r.confirmadas:
                match = next((d for d in dudosas if normalizar(d) == normalizar(c.palabra)), None)
                if match and respaldado(c.cita, cv.texto, 0.7):  # sin cita verificable no se acepta
                    confirmadas[match] = c.cita
        except SalidaInvalida:
            res.avisos.append("No pude confirmar con el modelo algunas palabras dudosas; las tomé como faltantes.")
        for d in dudosas:
            if d in confirmadas:
                res.presentes.append(PalabraPresente(d, "confirmada por el modelo", confirmadas[d]))
            else:
                res.faltantes.append(d)
    else:
        res.faltantes += dudosas

    est = oferta.estructura
    for req in est.requisitos:
        raices = _raices(req)
        if raices and len(raices & raices_cv) / len(raices) <= 0.5 and not any(
                normalizar(p.palabra) in normalizar(req) for p in res.presentes):
            res.no_cubiertos.append(req)
    pedidos, tiene = est.anios_experiencia, cv.estructura.anios_experiencia
    if pedidos and (tiene is None or tiene < pedidos):
        res.no_cubiertos.append(f"Pide {pedidos:g} años de experiencia; el CV no permite confirmarlos.")
    return res


# ------------------------------------------------------------------ generación
def _resumen_oferta(oferta: OfertaProcesada) -> str:
    e = oferta.estructura
    partes = []
    if e.titulo:
        partes.append(f"Puesto: {e.titulo}")
    if e.empresa:
        partes.append(f"Empresa: {e.empresa}")
    if e.requisitos:
        partes.append("Requisitos:\n" + "\n".join(f"- {r}" for r in e.requisitos[:8]))
    if e.deseables:
        partes.append("Deseables:\n" + "\n".join(f"- {r}" for r in e.deseables[:5]))
    texto = "\n".join(partes)
    if len(texto) < 120:  # el modelo no estructuró casi nada: se usa el aviso tal cual
        texto = truncar(oferta.texto, MAX_OFERTA_RESUMEN)[0]
    return truncar(texto, MAX_OFERTA_RESUMEN)[0]


def _pedido(cv, oferta: OfertaProcesada, analisis: AnalisisPalabras, correccion: str = "") -> str:
    presentes = ", ".join(p.palabra for p in analisis.presentes) or "(ninguna)"
    no_cubiertas = ", ".join(analisis.faltantes) or "(ninguna)"
    texto = (delimitar("cv", truncar(cv.texto, MAX_CV_ADAPTAR)[0]) + "\n\n"
             + delimitar("oferta", _resumen_oferta(oferta)) + f"\n\nPalabras clave presentes: {presentes}"
             + f"\nPalabras clave no cubiertas: {no_cubiertas}")
    if correccion:
        texto += "\n\n" + correccion
    return texto


def _limpiar_salida(texto: str) -> str:
    t = texto.strip()
    m = re.match(r"^```(?:markdown|md|text)?\s*\n(.*?)\n```$", t, re.S | re.I)
    return (m.group(1) if m else t).strip()


def _generar(sistema: str, cv, oferta, analisis, llm, cfg: Config, extra_sistema: str, max_tokens: int,
             vocabulario_extra) -> Generado:
    def una_vez(correccion: str = "") -> str:
        texto = _limpiar_salida(llm.chat_texto(sistema + extra_sistema, _pedido(cv, oferta, analisis, correccion),
                                               rol="principal", temperatura=0.4, max_tokens=max_tokens))
        if len(texto) < 80:
            raise SalidaInvalida("El modelo devolvió un texto vacío o demasiado corto.")
        return texto

    texto = una_vez()
    hallazgos = verificar(texto, cv.texto, oferta.texto, vocabulario_extra)
    if not hallazgos:
        return Generado(texto)
    lista = "; ".join(f"«{h.fragmento}» ({h.tipo})" for h in hallazgos[:10])
    correccion = (f"CORRECCIÓN: tu versión anterior incluyó datos que NO están en el CV: {lista}. "
                  "Escribila de nuevo sin esos datos ni ninguno otro que el CV no contenga.")
    try:
        texto2 = una_vez(correccion)
    except (SalidaInvalida, LLMError):
        return Generado(texto, hallazgos, regenerado=False)
    hallazgos2 = verificar(texto2, cv.texto, oferta.texto, vocabulario_extra)
    if len(hallazgos2) <= len(hallazgos):
        return Generado(texto2, hallazgos2, regenerado=True)
    return Generado(texto, hallazgos, regenerado=True)  # la segunda versión empeoró: se conserva la primera


def adaptar_cv(cv, oferta: OfertaProcesada, analisis: AnalisisPalabras, llm, cfg: Config,
               vocabulario_extra: list[str] | None = None) -> Generado:
    return _generar(cargar("adaptar_cv"), cv, oferta, analisis, llm, cfg, "", 1300, vocabulario_extra)


def redactar_carta(cv, oferta: OfertaProcesada, analisis: AnalisisPalabras, llm, cfg: Config, tono: str = "cercano",
                   vocabulario_extra: list[str] | None = None) -> Generado:
    if tono not in TONOS:
        raise ValueError(f"Tono desconocido: {tono}. Opciones: {', '.join(TONOS)}")
    return _generar(cargar("adaptar_carta"), cv, oferta, analisis, llm, cfg, "\n" + TONOS[tono], 700, vocabulario_extra)
