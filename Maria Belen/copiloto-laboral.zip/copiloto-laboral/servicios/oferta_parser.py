"""Lectura de una oferta pegada: texto -> datos estructurados (con filtro anti-invención)."""
from __future__ import annotations

from dataclasses import dataclass, field

from servicios.cv_parser import ErrorArchivo, _sin_ruido, _unir, _unir_idiomas, limpiar_texto
from servicios.llm_client import SalidaInvalida
from servicios.prompts import cargar
from servicios.schemas import OfertaEstructurada
from servicios.texto import delimitar, normalizar, respaldado, truncar
from servicios.vocabulario import herramientas_en_texto, idiomas_en_texto

MAX_CHARS_OFERTA = 4000
MIN_CHARS_OFERTA = 60


@dataclass
class OfertaProcesada:
    texto: str
    recortado: bool
    estructura: OfertaEstructurada
    herramientas: list[str]
    idiomas: list[str]
    palabras_clave: list[str]
    avisos: list[str] = field(default_factory=list)

    @property
    def texto_norm(self) -> str:
        return normalizar(self.texto)


def parsear_oferta(texto: str, llm, vocabulario_extra: list[str] | None = None) -> OfertaProcesada:
    texto = limpiar_texto(texto)
    if len(texto) < MIN_CHARS_OFERTA:
        raise ErrorArchivo("El aviso está vacío o es muy corto. Pegá el texto completo de la oferta.")
    texto, recortado = truncar(texto, MAX_CHARS_OFERTA)
    avisos = []
    if recortado:
        avisos.append(f"El aviso era largo y se usaron solo los primeros {MAX_CHARS_OFERTA} caracteres.")

    try:
        est = llm.chat_json(cargar("oferta_extraer"), delimitar("oferta", texto), OfertaEstructurada,
                            rol="principal", max_tokens=1200)
    except SalidaInvalida:
        est = OfertaEstructurada()
        avisos.append("El modelo no pudo analizar el aviso; sigo con lo que detecto por reglas (puede quedar incompleto).")

    est.requisitos = [r for r in est.requisitos if respaldado(r, texto, umbral=0.6)]
    est.deseables = [r for r in est.deseables if respaldado(r, texto, umbral=0.6)]
    est.herramientas = [h for h in est.herramientas if respaldado(h, texto)]
    est.idiomas = [i for i in est.idiomas if respaldado(i, texto)]
    est.palabras_clave = [k for k in est.palabras_clave if respaldado(k, texto)]
    for campo in ("titulo", "empresa"):
        if getattr(est, campo) and not respaldado(getattr(est, campo), texto):
            setattr(est, campo, "")
    if est.anios_experiencia is not None and not 0 <= est.anios_experiencia <= 40:
        est.anios_experiencia = None

    herramientas = _unir(_sin_ruido(herramientas_en_texto(texto, vocabulario_extra), texto), est.herramientas)
    idiomas = _unir_idiomas(idiomas_en_texto(texto), est.idiomas)
    palabras = _unir(herramientas, est.palabras_clave)[:25]
    return OfertaProcesada(texto=texto, recortado=recortado, estructura=est, herramientas=herramientas,
                           idiomas=idiomas, palabras_clave=palabras, avisos=avisos)
