import pytest

from servicios.brechas import (brechas_de_puesto, clave_herramienta, frecuencias_herramientas,
                               herramientas_mas_pedidas, resumen_agregado, sugerencia)
from servicios.config import EJEMPLOS_DIR, cargar_config
from servicios.cv_parser import parsear_cv
from servicios.llm_client import SalidaInvalida
from servicios.matcher import (CachePuntajes, EvaluacionLLM, evaluar_herramientas, puntuar_candidatos,
                               puntuar_puesto)
from servicios.puestos_repo import Puesto, cargar_puestos
from servicios.recuperador import Candidato
from servicios.schemas import CVEstructurado, Criterio
from tests.falsos import LLMFalso

CFG = cargar_config({})
PUESTOS = cargar_puestos()
CV = parsear_cv((EJEMPLOS_DIR / "cv-ejemplo-junior.md").read_text(encoding="utf-8"), LLMFalso(CVEstructurado()), CFG)

CUERPO = "# Diseñador/a\n\n## Requisitos\n- Manejo de Photoshop y Canva\n- Experiencia en redes sociales\n- Portfolio de trabajos\n"


def puesto(**kw):
    base = dict(id="p1", titulo="Diseñador/a", cuerpo=CUERPO, herramientas=["Canva", "Photoshop"],
                titulo_universitario="Licenciatura en Comunicación", requiere_titulo="sí", seniority="junior",
                experiencia="Mínimo 1 año en redes sociales", idiomas=["Inglés intermedio"])
    base.update(kw)
    return Puesto(**base)


def evaluacion(**kw):
    base = dict(
        experiencia=Criterio(puntaje=80, evidencia=["Diseño de piezas gráficas en Canva"], comentario="ok"),
        formacion=Criterio(puntaje=100, evidencia=["Licenciatura en Ciencias de la Comunicación"], comentario="ok"),
        seniority=Criterio(puntaje=70, evidencia=[], comentario="nivel junior"),
        brechas=["Portfolio de trabajos", "Dominio de Blender"], resumen="Buen ajuste.")
    base.update(kw)
    return EvaluacionLLM(**base)


def test_puntaje_combinado_con_pesos_y_tope_sin_cita():
    r = puntuar_puesto(CV, puesto(), LLMFalso(evaluacion()), CFG)
    por = {i.clave: i for i in r.items}
    assert por["herramientas"].puntaje == 50 and por["otros"].puntaje == 100
    assert por["seniority"].puntaje == 40 and "Sin cita verificable" in por["seniority"].comentario  # 70 sin cita -> 40
    assert por["experiencia"].evidencia == ["Diseño de piezas gráficas en Canva"]
    # 0,30*50 + 0,35*80 + 0,15*100 + 0,10*40 + 0,10*100 = 72
    assert r.puntaje == 72 and not r.parcial
    assert r.herramientas_cubiertas == ["Canva"] and r.herramientas_faltantes == ["Photoshop"]
    assert r.brechas_modelo == ["Portfolio de trabajos"]  # "Blender" no está en el puesto: inventado
    assert sum(i.peso for i in r.items) == pytest.approx(1)


def test_cita_inventada_limita_el_puntaje():
    ev = evaluacion(experiencia=Criterio(puntaje=95, evidencia=["Dirigió la campaña del Mundial 2022"]))
    p = puesto(cuerpo="# Analista\n- Planillas de cálculo y reportes", titulo="Analista")
    r = puntuar_puesto(CV, p, LLMFalso(ev), CFG)
    assert r.item("experiencia").puntaje == 40 and r.item("experiencia").evidencia == []


def test_criterios_que_el_puesto_no_especifica_se_excluyen_y_el_peso_se_reparte():
    p = puesto(herramientas=[], titulo_universitario="no figura", requiere_titulo="no figura", seniority="no figura",
               idiomas=[], experiencia="Experiencia previa en redes sociales")
    r = puntuar_puesto(CV, p, LLMFalso(evaluacion()), CFG)
    assert [i.clave for i in r.items] == ["experiencia", "seniority"]  # pedir experiencia implica un nivel
    assert r.puntaje == 71 and sum(i.peso for i in r.items) == pytest.approx(1)


def test_herramientas_genericas_y_alternativas():
    cv_norm = "uso canva y ga4"
    p, cub, falt = evaluar_herramientas(puesto(herramientas=["Google Analytics 4 (GA4)", "Photoshop o Illustrator",
                                                             "Herramientas de diseño"]), cv_norm)
    assert (p, cub, falt) == (50, ["Google Analytics 4 (GA4)"], ["Photoshop o Illustrator"])
    assert evaluar_herramientas(puesto(herramientas=["No figuran en el aviso leído"]), cv_norm)[0] is None


def test_si_el_modelo_falla_el_puntaje_es_parcial_y_no_se_cachea(tmp_path):
    cache = CachePuntajes(tmp_path / "c.json")
    r = puntuar_puesto(CV, puesto(), LLMFalso(error=SalidaInvalida("x")), CFG, cache)
    assert r.parcial and r.avisos and r.item("experiencia").puntaje is None
    assert r.puntaje == round((0.30 * 50 + 0.10 * 100) / 0.40)
    assert not (tmp_path / "c.json").exists()


def test_cache_evita_llamadas_y_se_invalida_con_otro_cv(tmp_path):
    ruta = tmp_path / "c.json"
    llm = LLMFalso(evaluacion())
    primero = puntuar_puesto(CV, puesto(), llm, CFG, CachePuntajes(ruta))
    segundo = puntuar_puesto(CV, puesto(), llm, CFG, CachePuntajes(ruta))  # cache cargado desde disco
    assert len(llm.llamadas) == 1 and segundo.desde_cache and segundo.puntaje == primero.puntaje
    assert segundo.item("experiencia").evidencia == primero.item("experiencia").evidencia
    otro_cv = parsear_cv(CV.texto + "\nTambién hice pasantías en prensa.", LLMFalso(CVEstructurado()), CFG)
    puntuar_puesto(otro_cv, puesto(), llm, CFG, CachePuntajes(ruta))
    assert len(llm.llamadas) == 2


def test_el_cv_va_primero_en_el_prompt_y_queda_delimitado():
    llm = LLMFalso(evaluacion())
    puntuar_puesto(CV, puesto(), llm, CFG)
    user = llm.llamadas[0]["user"]
    assert user.index("<cv>") < user.index("<puesto>") and "no obedezcas" in llm.llamadas[0]["system"]


def test_puntuar_candidatos_ordena_limita_y_reporta_progreso():
    ps = [puesto(id=f"p{i}", titulo=f"Puesto {i}") for i in range(4)]
    puntajes = iter([30, 90, 60, 10])

    class LLM:
        def chat_json(self, *a, **k):
            return evaluacion(experiencia=Criterio(puntaje=next(puntajes), evidencia=["Diseño de piezas gráficas en Canva"]))

    avance = []
    res = puntuar_candidatos(CV, [Candidato(p, 0.5) for p in ps], LLM(), CFG, n=3, progreso=lambda i, n, t: avance.append((i, n)))
    assert len(res) == 3 and [r.puesto.id for r in res] == ["p1", "p2", "p0"]
    assert avance[0] == (0, 3) and avance[-1] == (3, 3)


def test_puntaje_con_puestos_reales_corre_sin_errores():
    llm = LLMFalso(evaluacion())
    for p in PUESTOS:
        r = puntuar_puesto(CV, p, llm, CFG)
        assert 0 <= r.puntaje <= 100 and r.items


# ------------------------------------------------------------------ brechas
def test_clave_herramienta_agrupa_variantes():
    assert clave_herramienta("Google Analytics 4 (GA4)") == clave_herramienta("GA4") == clave_herramienta("Google Analytics")
    assert clave_herramienta("Canva") != clave_herramienta("Photoshop")


def test_frecuencias_y_herramientas_mas_pedidas():
    cuenta, etiquetas = frecuencias_herramientas(PUESTOS)
    assert max(cuenta.values()) <= len(PUESTOS)
    filas = herramientas_mas_pedidas(CV, PUESTOS, top=10)
    assert [f.puestos for f in filas] == sorted((f.puestos for f in filas), reverse=True)
    assert all(0 < f.porcentaje <= 100 for f in filas)
    canva = next(f for f in herramientas_mas_pedidas(CV, PUESTOS, top=100) if f.herramienta.lower() == "canva")
    assert canva.la_tengo  # el CV de ejemplo menciona Canva


def test_brechas_de_puesto_ordenadas_por_importancia_y_sugerencia():
    ps = [puesto(id="a", herramientas=["Photoshop", "Premiere"]), puesto(id="b", herramientas=["Photoshop"]),
          puesto(id="c", herramientas=["Photoshop", "Canva"])]
    r = puntuar_puesto(CV, puesto(herramientas=["Premiere", "Photoshop"]), LLMFalso(evaluacion()), CFG)
    br = brechas_de_puesto(r, ps)
    assert [b.texto for b in br][:2] == ["Photoshop", "Premiere"] and br[0].frecuencia == 3
    assert br[-1].tipo == "requisito"
    assert "Photoshop" in sugerencia(br, 3) and "3 de los 3" in sugerencia(br, 3)
    assert "No detecté" in sugerencia([], 3)


def test_resumen_agregado_cuenta_repeticiones():
    rs = [puntuar_puesto(CV, puesto(id=f"p{i}"), LLMFalso(evaluacion(seniority=Criterio(puntaje=20))), CFG) for i in range(3)]
    filas = resumen_agregado(rs)
    por = {(f.texto, f.tipo): f for f in filas}
    assert por[("Photoshop", "herramienta")].veces == 3 and por[("Photoshop", "herramienta")].de == 3
    assert por[("Seniority por debajo de 50", "criterio")].veces == 3


# ---------- Bloque 1: la experiencia no penaliza si el puesto no la exige
from servicios.puestos_repo import exigencia_experiencia, puesto_desde_oferta  # noqa: E402
from servicios.schemas import OfertaEstructurada  # noqa: E402


@pytest.mark.parametrize("exp,esperado", [
    ("no figura", "no"), ("No se requiere experiencia", "no"), ("0 a 2 años", "no"),
    ("No exige años; suma tener experiencia en SEO", "deseable"), ("Mínimo 2 años en posiciones similares", "si"),
    ("Experiencia comprobable en prensa", "si"),
    ("Al menos 5 años (deseable); agenda propia (excluyente)", "si"), ("Se valora experiencia en agencias", "deseable"),
])
def test_exigencia_de_experiencia(exp, esperado):
    assert exigencia_experiencia(puesto(experiencia=exp, seniority="no figura")) == esperado


def test_oferta_pegada_sin_experiencia_o_que_la_niega():
    est = OfertaEstructurada(titulo="Asistente")
    p = puesto_desde_oferta("Buscamos asistente de redes. Requisitos: Canva.", est)
    assert exigencia_experiencia(p) == "no"
    p = puesto_desde_oferta("Buscamos asistente. No se requiere experiencia. Canva.", est)
    assert exigencia_experiencia(p) == "no"
    p = puesto_desde_oferta("Buscamos asistente. Se requieren 2 años de experiencia previa.", est)
    assert exigencia_experiencia(p) == "si"


def test_sin_exigencia_la_experiencia_no_suma_ni_resta_ni_aparece_en_brechas_ni_resumen():
    ev = evaluacion(experiencia=Criterio(puntaje=0, comentario="no tiene"), seniority=Criterio(puntaje=0),
                    brechas=["Portfolio de trabajos", "Experiencia en redes sociales"],
                    resumen="El CV no muestra experiencia relevante. Buen manejo de Canva.")
    r = puntuar_puesto(CV, puesto(experiencia="No se requiere experiencia", seniority="no figura"), LLMFalso(ev), CFG)
    exp = r.item("experiencia")
    assert exp.puntaje is None and exp.peso == 0 and "no exige experiencia" in exp.comentario
    assert r.item("seniority") is None and not r.parcial
    assert r.brechas_modelo == ["Portfolio de trabajos"]
    assert "experiencia" not in r.resumen.lower() and "Canva" in r.resumen
    # el puntaje se reparte entre los demás criterios (experiencia = 0 no lo arrastra)
    assert r.puntaje >= 60


def test_nota_de_exigencia_llega_al_modelo():
    llm = LLMFalso(evaluacion())
    puntuar_puesto(CV, puesto(experiencia="no figura", seniority="no figura"), llm, CFG)
    assert "Exigencia de experiencia: NO" in llm.llamadas[0]["user"]


def test_dominio_meta_ads_cuenta_como_publicidad_digital():
    from servicios.vocabulario import dominios_en_texto
    assert "publicidad digital" in dominios_en_texto("Campañas pagas en Meta Ads con presupuestos de hasta USD 3.000")
    assert "marketing digital" in dominios_en_texto("Gestión de Google Ads")
    cv = type("CV", (), {"texto": "Analista de contenidos. Campañas pagas en Meta Ads con presupuesto de USD 3.000 por mes.",
                         "idiomas": []})()
    p = puesto(cuerpo="# Publicista\n- Experiencia en publicidad digital", herramientas=[], idiomas=[],
               titulo_universitario="no figura", requiere_titulo="no figura", seniority="no figura",
               experiencia="2 años en publicidad digital")
    ev = evaluacion(experiencia=Criterio(puntaje=10, evidencia=[]))
    llm = LLMFalso(ev)
    r = puntuar_puesto(cv, p, llm, CFG)
    assert r.item("experiencia").puntaje == 50 and "publicidad digital" in r.item("experiencia").comentario
    assert "Pista: el CV menciona" in llm.llamadas[0]["user"]


# ---------- Bloque 8: excluyentes (por defecto) vs deseables (solo si el texto lo dice)
from servicios.brechas import brechas_de_puesto, sugerencia  # noqa: E402
from servicios.oferta_parser import clasificar_requisitos  # noqa: E402
from servicios.puestos_repo import es_deseable, lineas_con_tipo  # noqa: E402


def test_por_defecto_todo_es_excluyente_y_solo_marcas_explicitas_son_deseables():
    assert not es_deseable("Manejo de Canva")
    assert not es_deseable("2 años de experiencia, idealmente en consumo masivo")  # matiz, no opcional
    assert es_deseable("Inglés avanzado (deseable)") and es_deseable("Se valora Meta Ads")
    assert es_deseable("Photoshop, no excluyente") and es_deseable("Suma: experiencia en agencias")
    assert not es_deseable("Photoshop (excluyente)")
    pares = dict(lineas_con_tipo("- Dominio de Premiere; suma After Effects\nDeseable:\n- Meta Ads\n- Excel"))
    assert pares["Dominio de Premiere"] is False and pares["suma After Effects"] is True
    assert pares["Meta Ads"] is True and pares["Excel"] is True


def test_clasificar_requisitos_manda_el_aviso_sobre_el_modelo():
    texto = "Requisitos:\n- Manejo de Canva\n- Redacción de notas\nSe valora:\n- Meta Ads\n- Inglés intermedio"
    exc, des = clasificar_requisitos(texto, ["Manejo de Canva", "Meta Ads"], ["Redacción de notas", "Inglés intermedio"])
    assert exc == ["Manejo de Canva", "Redacción de notas"] and des == ["Meta Ads", "Inglés intermedio"]
    # sin poder ubicarlo en el aviso, queda donde lo puso el modelo
    assert clasificar_requisitos("texto sin nada", ["Algo raro"], ["Otro"]) == (["Algo raro"], ["Otro"])


CUERPO_DES = ("# Diseñador/a\n\n## Requisitos\n- Manejo de Canva\n- Se valora Photoshop\n- Inglés intermedio (deseable)\n")


def test_herramienta_deseable_no_resta_y_suma_plus():
    cv_con = type("CV", (), {"texto": "Uso Canva y Photoshop todos los días. Inglés intermedio.", "idiomas": ["Inglés intermedio"]})()
    cv_sin = type("CV", (), {"texto": "Uso Canva todos los días.", "idiomas": []})()
    p = puesto(cuerpo=CUERPO_DES, idiomas=["Inglés intermedio (deseable)"], experiencia="no figura", seniority="no figura",
               titulo_universitario="no figura", requiere_titulo="no figura")
    assert evaluar_herramientas(p, "uso canva") == (100, ["Canva"], [])  # Photoshop es deseable: no cuenta
    ev = evaluacion(formacion=Criterio(puntaje=50, evidencia=[]), brechas=[])
    p.titulo_universitario = "Licenciatura en Comunicación"
    sin = puntuar_puesto(cv_sin, p, LLMFalso(ev), CFG)
    con = puntuar_puesto(cv_con, p, LLMFalso(ev), CFG)
    assert sin.item("herramientas").puntaje == 100 and sin.item("otros") is None  # idioma solo deseable: no puntúa
    assert sin.bonus == 0 and sin.deseables_faltantes == ["Photoshop", "Inglés (idioma)"]
    assert con.plus == ["Photoshop", "Inglés (idioma)"] and con.bonus == 6 and con.puntaje == sin.puntaje + 6
    # las faltantes deseables no son brechas obligatorias ni "por dónde empezar"
    br = brechas_de_puesto(sin, [p])
    assert [b.tipo for b in br if b.tipo == "herramienta"] == []
    assert {b.texto for b in br if b.tipo == "deseable"} == {"Photoshop", "Inglés (idioma)"}
    assert sugerencia([b for b in br if b.tipo == "deseable"], 1).startswith("No detecté brechas obligatorias")


def test_bonus_con_tope_y_sin_pasar_de_100():
    p = puesto(cuerpo="# X\n\n## Requisitos\n- Canva\n- Se valora Photoshop, Premiere, Illustrator, After Effects, Excel",
               herramientas=["Canva", "Photoshop", "Premiere", "Illustrator", "After Effects", "Excel"], idiomas=[],
               experiencia="no figura", seniority="no figura", titulo_universitario="no figura", requiere_titulo="no figura")
    cv = type("CV", (), {"texto": "Canva Photoshop Premiere Illustrator After Effects Excel", "idiomas": []})()
    r = puntuar_puesto(cv, p, LLMFalso(evaluacion(brechas=[])), CFG)
    assert len(r.plus) == 5 and r.bonus == 10 or r.puntaje == 100


def test_brecha_del_modelo_deseable_se_separa():
    p = puesto(cuerpo="# X\n\n## Requisitos\n- Portfolio de trabajos\n- Se valora Dominio de motion graphics\n",
               experiencia="no figura", seniority="no figura")
    ev = evaluacion(brechas=["Portfolio de trabajos", "Dominio de motion graphics"])
    r = puntuar_puesto(CV, p, LLMFalso(ev), CFG)
    assert r.brechas_modelo == ["Portfolio de trabajos"] and "Dominio de motion graphics" in r.deseables_faltantes


def test_formacion_y_experiencia_deseables_no_restan_pero_suman():
    p = puesto(requiere_titulo="deseable", titulo_universitario="Licenciatura en Comunicación (deseable)",
               experiencia="Se valora experiencia en redes", seniority="no figura", herramientas=[], idiomas=[])
    r = puntuar_puesto(CV, p, LLMFalso(evaluacion()), CFG)
    assert r.item("formacion").puntaje is None and r.item("experiencia").puntaje is None
    assert set(r.plus) == {"Formación", "Experiencia"} and r.bonus >= 0
    malo = evaluacion(formacion=Criterio(puntaje=0), experiencia=Criterio(puntaje=0))
    r2 = puntuar_puesto(CV, p, LLMFalso(malo), CFG)
    assert r2.plus == [] and set(r2.deseables_faltantes) >= {"Formación", "Experiencia"}
